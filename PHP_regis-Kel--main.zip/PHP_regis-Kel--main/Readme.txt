Instructions:

1. Place the directory in the CPanel of server
2. config database connection in Php/View/connect.php

Scalable:

1.in teacher subject increases config echo 
        "<option value =\"" . " " . "\">" . "--" . "</option>";
        echo "<option value =\"" . $row['subject1'] . "\">" .  $row['subject1']  . "</option>";
        echo "<option value =\"" . $row['subject2'] . "\">" .  $row['subject2']  . "</option>";
        echo "<option value =\"" . $row['subject3'] . "\">" .  $row['subject3']  . "</option>";"
        //add lines
in ajaxtemp.php for asynchronous calls

except index all hidden .html