module.exports = {
    content: ["*.html", "Php\\View\\Forms\\*.php"],
    theme: {
        extend: {},
    },
    plugins: [],
}