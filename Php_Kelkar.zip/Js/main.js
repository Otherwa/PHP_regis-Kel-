let var1 = 2;
let var2 = 2;
let var_ans = var1 + var2;
let var_ans2 = var1 + var2 - 1;
console.log(`${var1} + ${var2} is ${var_ans} - 1 that's ${var_ans2} Quick Mafs`);